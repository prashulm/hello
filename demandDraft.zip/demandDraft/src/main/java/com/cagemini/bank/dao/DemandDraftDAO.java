package com.cagemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;


import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {
	final static Logger logger=Logger.getLogger(DemandDraftDAO.class);
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		// TODO Auto-generated method stub
       String sql="insert into demand_draft(customerName,inFavourOf,PhoneNo,TransactionDate,ddAmount,ddCommission,ddDescription) values(?,?,?,?,?,?,?);";
		
		int temp=0;
		try(Connection connection=getConnection())
		{
			Date date=Date.valueOf(demandDraft.getDate_of_transaction());
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1,demandDraft.getCustomer_name());
			statement.setString(2, demandDraft.getInFavourOf());
			statement.setString(3, demandDraft.getPhone_number());
			statement.setDate(4, date);
			statement.setDouble(5, demandDraft.getDd_amount());
			statement.setDouble(6, demandDraft.getDd_commission());
			statement.setString(7, demandDraft.getDd_description());
			
			
			
			int row=statement.executeUpdate();
			
			if(row>0)
				{String str="select max(transactionid) from demand_draft";
				
		java.sql.PreparedStatement pst2=connection.prepareStatement(str);		
				ResultSet res1=pst2.executeQuery();
				
				while(res1.next())
				 temp=res1.getInt(1);
				
				}
			
		} catch (SQLException e) {
			
		logger.error("SQL Exception while inserting in DB!");
			e.printStackTrace();
		}
		
		
		return temp;
		
	}

	public DemandDraft getDemandDraftDetails(int a) {
		// TODO Auto-generated method stub
		
		
			System.out.println("your demand draft request has been successfully registered along with the transaction id"+ a);

			
		return null;
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hello", "root", "root");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
		logger.error("Connection Error!");
			e.printStackTrace();
		}
		return null;
	}
	

}
