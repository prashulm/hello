package com.capgemini.bank.service;


import org.apache.log4j.Logger;

import com.cagemini.bank.dao.DemandDraftDAO;
import com.cagemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.InvalidAmountException;

public class DemandDraftService implements IDemandDraftService {

	final static Logger logger=Logger.getLogger(DemandDraftService.class);
	IDemandDraftDAO dao=new DemandDraftDAO();
	
	public DemandDraftService(IDemandDraftDAO dao) {
		super();
		this.dao = dao;
	}
	
	public DemandDraftService()	{}
	
	
	public int addDemandDraftDetails(DemandDraft demandDraft) throws InvalidAmountException {
		 if(demandDraft.getDd_amount()<=0)
		{
			logger.error("Invalid Amount entered!");
			throw new InvalidAmountException("Invalid Amount!");
		}
		
		return dao.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transaction_id) {
		// TODO Auto-generated method stub
		return dao.getDemandDraftDetails(transaction_id);
	}

}
