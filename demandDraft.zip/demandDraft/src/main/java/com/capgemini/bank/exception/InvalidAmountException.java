package com.capgemini.bank.exception;

public class InvalidAmountException extends Exception {
	
	public InvalidAmountException(String message) {
		super(message);
}
}
