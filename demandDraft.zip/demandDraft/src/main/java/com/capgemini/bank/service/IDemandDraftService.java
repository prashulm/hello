package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.InvalidAmountException;

public interface IDemandDraftService {
public  int addDemandDraftDetails(DemandDraft demandDraft) throws InvalidAmountException;
public DemandDraft getDemandDraftDetails(int transaction_id);
}
