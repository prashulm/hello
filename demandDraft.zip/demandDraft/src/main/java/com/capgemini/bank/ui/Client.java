package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.InvalidAmountException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;


public class Client {

	
//	IRegistrationService registrationServices=new RegistrationServiceImpl();
	Scanner sc=new Scanner(System.in);
	
	public  DemandDraft getDemandDraftDetails()
	{
		DemandDraft dd=new DemandDraft();
		dd.setCustomer_name(promptCustomerName());
		dd.setPhone_number(promptCustomerMobileNo());
		dd.setDate_of_transaction(promptDateOfTransaction());
		dd.setDd_amount(promptDemandDraftAmount());
		dd.setDd_description(promptDescription());
		dd.setInFavourOf(promptInFavourOf());
		
dd.setDd_commission(calculateCommission(dd.getDd_amount()));
		
		return dd;
	}
	
	public String promptCustomerName()
	{
		while(true)	{
			String name;
			System.out.println("Enter the name of the customer : ");
			name=sc.next();
			if(isValidCustomerName(name))
				return name;
		}
	}
	
	public boolean isValidCustomerName(String name)
	{
		if(name.matches("[A-Za-z]{3,}"))
			return true;
		else
			return false;	
	}
	
	public String promptCustomerMobileNo()
	{
		while(true) {
			String mobile;
			System.out.println("Enter customer phone number: ");
			mobile=sc.next();
			if(isValidMobileNo(mobile))
			return mobile;
		}
	}
	
	public boolean isValidMobileNo(String mobile)
	{
		if(mobile.matches("\\d{10}")) 
			return true;
		else
			return false;	
	}
	
	public String promptInFavourOf()
	{
		String inFavourOf;
			System.out.println("In favour of : ");
			inFavourOf=sc.next();
			return inFavourOf;
		
	}
	
	public double promptDemandDraftAmount()
	{
		double amount;
		System.out.println("Enter Demand Draft amount (in Rs) : ");
		amount=sc.nextDouble();
		return amount;
	}
	
	public LocalDate promptDateOfTransaction() {
		boolean flag=false;
		String dot;
		do {
			System.out.println("Enter DateOfTransaction[dd-mm-yyyy]:");
			dot=sc.next();
			flag=isValidDot(dot);
			if(!flag)
				System.out.println("Please enter Valid Date!");
		}while(!flag);
		String[] dates=dot.split("-");
		LocalDate date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return date;
	}
	
	public String promptDescription()
	{
		String description;
			System.out.println("Enter Remarks: ");
			description=sc.next();
			return description;
		
	}
	
	
	
	
	public double calculateCommission(double dd_amount)
	{
		double commission=0;
		if(dd_amount<=5000)
			commission=dd_amount+10;
		else if(dd_amount>5000 && dd_amount<=10000)
			commission=dd_amount+41;
		else if(dd_amount>10001 && dd_amount<=100000)
			commission=dd_amount+51;
		else if(dd_amount>100000 && dd_amount<=500000)
			commission=dd_amount+306;
		
		return commission;
	}
	
	
	
public static boolean isValidDot(String dot) {
		
		return dot.matches("[0,1,2,3]\\d{1}-[0,1]\\d{1}-(18|19|20)\\d{2}");
	}
	
	
//	public void generateAcknowledgement()
//	{
//		registration=registrationServices.getRegistrationDetails();
//		System.out.println("\n\n\tACKNOWLEDGEMENT SLIP");
//		System.out.println("Registration ID: "+registration.getRegistrationId());
//		System.out.println("CONGRATULATIONS "+registration.getCustomerName()+"!!");
//		System.out.println("Amount paid:\t"+registration.getActualRegistrationFeesPaid()+"\n\n");
//	}
//	
	public static void main(String[] args) throws InvalidAmountException {
		Client client=new Client();
		DemandDraft dd=new DemandDraft();
		IDemandDraftService service=new DemandDraftService();
		int choice;
		Scanner sc=new Scanner(System.in);
//		UserInteraction ui=new UserInteraction();
//		IRegistrationService registrationService=new RegistrationServiceImpl();
		while(true)	{
			System.out.println("Make a choice:");
			System.out.println("1. Enter demand draft details");
			System.out.println("2. Exit");
			char option;
			choice=sc.nextInt();
				do {
				switch(choice)
				{
				case 1:
					
					 dd= client.getDemandDraftDetails();
                        int a=service.addDemandDraftDetails(dd);
                        service.getDemandDraftDetails(a);
					
			
				
//					registration=ui.getRegistrationDetails();
//					logger.info("Customer details fetched from DB!");
//					registrationService.createRegistration(registration);
//					ui.generateAcknowledgement();
//					logger.info("Customer added to Registration DB!");
				break;
				case 2:
					System.out.println("Bye");
					System.exit(0);
				break;
				}
				System.out.println("do you want to continue Enter [y/n]: ");
				option= sc.next().charAt(0);
			
		
				}while(option=='Y' || option=='y');
		}
	}
}
	

