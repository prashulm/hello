package demandDraft;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cagemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.InvalidAmountException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class CustomerServiceTest {

	@Mock
	IDemandDraftDAO demanddraftDao;

	static IDemandDraftService registrationServices;
	
	@Before
	public void init()	{
		MockitoAnnotations.initMocks(this);
		registrationServices=new DemandDraftService(demanddraftDao);
		
	}	
		
	@Test
	public void test_acc_proper_format() throws InvalidAmountException
	{
		DemandDraft demand=new DemandDraft();
		demand.setCustomer_name("gargi");
		demand.setInFavourOf("hi");
		demand.setDd_amount(1);
		demand.setDd_description("nothing");
		demand.setDate_of_transaction(LocalDate.of(2000, 12, 23));
		
		demand.setDd_commission(12);
		demand.setPhone_number("3216549870");
		
		Mockito.when(demanddraftDao.addDemandDraftDetails(demand)).thenReturn(1);
		registrationServices.addDemandDraftDetails(demand);
		Mockito.verify(demanddraftDao).addDemandDraftDetails(demand);
		}
	}


